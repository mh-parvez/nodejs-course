## For 1 byte character
`0xxxxxxx`

## For 2 bytes character
`110xxxxx 10xxxxxx`


## For 3 bytes character
`1110xxxx 10xxxxxx 10xxxxxx`
`11101111 10111011 10111111`



## For 4 bytes character
`11110xxx 10xxxxxx 10xxxxxx 10xxxxxx`